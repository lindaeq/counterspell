class Past:
    def __init__(self, prev):
        self.prev = prev